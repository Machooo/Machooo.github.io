=== Woocommerce checkout field editor ===

Contributors: solwininfotech
Tags: checkout custome field, woocommerce checkout add field,checkout, custom field, manage checkout field, woocommerce checkout, add checkout field, add custom field, Additional Fields, new fields, payment, billing address, billing, billing field, custom billing field, shipping address, shipping, shipping  fields, custom shipping field, custom field style, option, edit field, edit placeholder, edit lable, Text Inputbox, Check Box, Select Options, Date Picker, Multiple Selection, Textarea Input, text box, woocommerce, wordpress, Country, address, city, order, information, manage, option, solution.
Requires at least: 3.0

Tested up to: 4.2.2


License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Stable tag: 3.7

Woocommerce Checkout page billing and shipping field editor.



== Description ==
WooCommerce checkout page have limited field for billing and shipping and many user need to add new fields or customize fields to provide better billing and shipping service. Now its easy to add new fields and customize WooCommerce by default billing and shipping fields with hep of Woocommerce checkout field editor plugin.

**Feature list**

* Add new billing or shipping field on checkout page.
* Add new fields under Additional Fields section.
* Remove any billing or shipping field on checkout.
* Customize checkout fields (lable, Is Required field, Placeholder text)
* Add css class in checkout fields to give style.

* New added billing or shipping fields will appear on Order Summary, Receipt and Back-end in Orders.
* Six ( 6 ) different fields types included: Text Input, Check Box, Select Options, Date Picker, Multiple Selection, Textarea Input.
* check box to display or hide "Additional Fields" section name on the Order Summary and Receipt.
 



== Installation ==

= From your WordPress dashboard =

1. Visit 'Plugins > Add New'
2. Search for 'Woocommerce checkout field editor', locate plugin and install,
3. Alternately, Upload the wc-checkout-field-editor.zip,
4. Alternately, upload wc-checkout-field-editor directory to the /wp-content/plugins/ directory via FTP,
3. Activate 'Woocommerce checkout field editor' from your Plugins page.


== Frequently asked questions ==

= A question that someone might have =

An answer to that question.



== Screenshots ==



1. Woocommerce checkout field editor admin interface for billing section

2. Woocommerce checkout field editor admin interface for shipping section

3. Woocommerce checkout field editor admin interface for additional section

4. Woocommerce checkout field editor user interface for date picker

5. Woocommerce checkout field editor user interface for Multiple selection

6. Woocommerce checkout field editor user interface for extra field


== Changelog ==


== Upgrade notice ==


== Arbitrary section 1 ==